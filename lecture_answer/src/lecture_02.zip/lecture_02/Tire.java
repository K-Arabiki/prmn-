package lecture_02;

public class Tire {
    int size;

    public Tire (int size){
        this.size = size;
    }
}
