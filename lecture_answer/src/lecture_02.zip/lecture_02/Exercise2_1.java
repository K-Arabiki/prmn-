package lecture_02;

public class Exercise2_1 {
    public static void main(String[] args) {

        Human human1 = new Human("こうき",20);
        human1.print();

        Human human2 = new Human("かんた",16);
        human2.print();
    }
}
